﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dotp3p6
{
    public partial class Form1 : Form
    {
        ArrayList arl = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if(comboBox1.Text=="String")
                {
                    arl.Add(textBox1.Text);
                    listBox1.Items.Clear();
                    display();
                }
                else if (comboBox1.Text == "Number")
                {
                    arl.Add(Convert.ToInt32( textBox1.Text));
                    listBox1.Items.Clear();
                    display();
                }
                else if (comboBox1.Text == "Boolean")
                {
                    arl.Add(Convert.ToBoolean( textBox1.Text));
                    listBox1.Items.Clear();
                    display();
                }
                else if (comboBox1.Text == "Float")
                {
                    arl.Add(Convert.ToDouble( textBox1.Text));
                    listBox1.Items.Clear();
                    display();
                }
                else
                {
                    MessageBox.Show("Please select something");
                }
                
            }
            catch { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void display()
        {
            foreach (object obj in arl)
            {
                listBox1.Items.Add(obj);
            }
        }

       
        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.Text == "String")
                {
                    arl.Remove(textBox1.Text);
                    listBox1.Items.Clear();
                    display();
                }
                else if (comboBox1.Text == "Number")
                {
                    arl.Remove(Convert.ToInt32(textBox1.Text));
                    listBox1.Items.Clear();
                    display();
                }
                else if (comboBox1.Text == "Boolean")
                {
                    arl.Remove(Convert.ToBoolean(textBox1.Text));
                    listBox1.Items.Clear();
                    display();
                }
                else if (comboBox1.Text == "Float")
                {
                    arl.Remove(Convert.ToDouble(textBox1.Text));
                    listBox1.Items.Clear();
                    display();
                }
                else
                {
                    MessageBox.Show("Please select something");
                }

            }
            catch { }
        }
    }
}