﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dotp3p3
{
    public partial class Form1 : Form
    {
        Button[,] btn;
        Button b,reset;
        int flag = 0,tiecheck=0, cnt = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Label lbl = new Label();
            lbl.Text = "Tic-Tac-Toe";
            lbl.Font = new Font("Tic-Tac-Toe", 20);
            lbl.Height = 37;
            lbl.Width = 189;
            lbl.Left = 178;
            lbl.Top = 74;
            this.Controls.Add(lbl);
            btn = new Button[3, 3];
            int width = 70, height = 70, left = 150, top = 150;
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    b = new Button();
                    b.Height = height;
                    b.Width = width;
                    b.Left = left + (width + 10) * j;
                    b.Top = top + (height + 10) * i;
                    b.Name = "p" + cnt;
                    btn[i, j] = b;
                    this.Controls.Add(btn[i, j]);
                    cnt++;
                }
            }
            reset = new Button();
            reset.Height = 50;
            reset.Width = 100;
            reset.Text = "Restart";
            reset.Top = 448;
            reset.Left = 221;
            reset.Font = new Font("Restart", 16);
            Controls.Add(reset);
            EventHandler rbc = new EventHandler(resetButton_Click);
            reset.Click += rbc;
            EventHandler eh = new EventHandler(mybutton_click);
            btn[0, 0].Click += eh;
            btn[0, 1].Click += eh;
            btn[0, 2].Click += eh;
            btn[1, 0].Click += eh;
            btn[1, 1].Click += eh;
            btn[1, 2].Click += eh;
            btn[2, 0].Click += eh;
            btn[2, 1].Click += eh;
            btn[2, 2].Click += eh;
        }
        private void resetButton_Click(object sender, EventArgs e)
        {
            for(int i=0;i<3;i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    btn[i, j].Text = "";
                }
            }
            flag = 0;
            tiecheck = 0;
            cnt = 0;
        }
        private void mybutton_click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (b.Text == "")
            {
                if (flag == 0)
                {
                    b.Text = "0";
                    b.Font = new Font("0", 16);
                    flag = 1;
                    tiecheck++;
                    checkResult(sender,e);
                }
                else if (flag == 1)
                {
                    b.Text = "X";
                    b.Font = new Font("X", 16);
                    flag = 0;
                    tiecheck++;
                    checkResult(sender, e);
                }
                
            }
            else
            {
                MessageBox.Show("You cannot play here");
            }
        }
        private void checkResult(object sender, EventArgs e)
        {
            
            if ((btn[0, 0].Text == "0" && btn[0, 1].Text == "0" && btn[0, 2].Text == "0") ||
                (btn[1, 0].Text == "0" && btn[1, 1].Text == "0" && btn[1, 2].Text == "0") ||
                (btn[2, 0].Text == "0" && btn[2, 1].Text == "0" && btn[2, 2].Text == "0") ||
                (btn[0, 0].Text == "0" && btn[1, 0].Text == "0" && btn[2, 0].Text == "0") ||
                (btn[0, 1].Text == "0" && btn[1, 1].Text == "0" && btn[2, 1].Text == "0") ||
                (btn[0, 2].Text == "0" && btn[1, 2].Text == "0" && btn[2, 2].Text == "0") ||
                (btn[0, 0].Text == "0" && btn[1, 1].Text == "0" && btn[2, 2].Text == "0") ||
                (btn[2, 0].Text == "0" && btn[1, 1].Text == "0" && btn[0, 2].Text == "0"))
            {
                MessageBox.Show("Player 1 is winner\n");
                resetButton_Click(sender,e);
            }
            else if ((btn[0, 0].Text == "X" && btn[0, 1].Text == "X" && btn[0, 2].Text == "X") ||
                (btn[1, 0].Text == "X" && btn[1, 1].Text == "X" && btn[1, 2].Text == "X") ||
                (btn[2, 0].Text == "X" && btn[2, 1].Text == "X" && btn[2, 2].Text == "X") ||
                (btn[0, 0].Text == "X" && btn[1, 0].Text == "X" && btn[2, 0].Text == "X") ||
                (btn[0, 1].Text == "X" && btn[1, 1].Text == "X" && btn[2, 1].Text == "X") ||
                (btn[0, 2].Text == "X" && btn[1, 2].Text == "X" && btn[2, 2].Text == "X") ||
                (btn[0, 0].Text == "X" && btn[1, 1].Text == "X" && btn[2, 2].Text == "X") ||
                (btn[2, 0].Text == "X" && btn[1, 1].Text == "X" && btn[0, 2].Text == "X"))
            {
                MessageBox.Show("Player 2 is winner\n");
                resetButton_Click(sender, e);
            }
            else if(tiecheck==9)
            {
                MessageBox.Show("Match is tied");
                resetButton_Click(sender, e);
            }
        }
    }
}