﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotp2p3
{
    class core_calculator
    {
        protected double num1, res;
        public core_calculator()
        {
            num1 = res = 0;
        }
        public double add(double num1,double res)
        {
            this.num1 = num1;
            this.res = res;
            res =  res+ num1;
            return res;
        }
        public double minus(double num1, double res)
        {
            this.num1 = num1;
            this.res = res;
            res = res-num1;
            return res;
        }
        public double mul(double num1, double res)
        {
            
            this.num1 = num1;
            this.res = res;
            res =   res*num1;
            return res;
        }
        public double div(double num1, double res)
        {
            this.num1 = num1;
            this.res = res;
            res = res / num1;
            return res;
        }
    }
}
