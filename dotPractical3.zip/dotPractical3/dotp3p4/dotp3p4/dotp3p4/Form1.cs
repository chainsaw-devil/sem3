﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dotp3p4
{
    public partial class Form1 : Form
    {
        Button[,] btn;
        int empR, empC,setText;
        public Form1()
        {
            InitializeComponent();
            empR = empC = 2;
            setText = 8;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btn = new Button[3,3];
            Label lbl = new Label();
            lbl.Text = "Sliding-Box";
            lbl.Font = new Font("Sliding-Box", 20);
            lbl.Height = 37;
            lbl.Width = 189;
            lbl.Left = 178;
            lbl.Top = 74;
            Controls.Add(lbl);
            int height = 70, width = 70,left=150,top=150;
            for(int i=0;i<3;i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Button b = new Button();
                    b.Height = height;
                    b.Width = width;
                    b.Left = left + (width + 10) * j;
                    b.Top = top + (height + 10) * i;
                    if(setText==0)
                    {
                        setText = 8;
                    }
                    b.Text = setText.ToString();
                    setText--;
                    btn[i, j] = b;
                    Controls.Add(btn[i, j]);
                    EventHandler eh = new EventHandler(setGame);
                    btn[i, j].Click += eh;
                }
            }
            btn[empR, empC].Text = null;
            btn[empR, empC].Enabled = false;


        }
        private void setGame(object sender, EventArgs e)
        {
            Button bsg = (Button)sender;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if(btn[i,j].Text==bsg.Text)
                    {
                        if(empR==i-1&&empC==j||
                            empR==i&&empC==j-1||
                            empR==i+1&&empC==j||
                            empR == i && empC == j + 1)
                        {
                            btn[empR, empC].Enabled = true;
                            btn[empR, empC].Text = bsg.Text;
                            btn[i, j].Text = null;
                            btn[i, j].Enabled = false;
                            empR = i;
                            empC = j;
                            checkWin();
                        }
                    }
                }
            }
        }
        private void checkWin()
        {
            int cnt = 1;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if(btn[i,j].Text==cnt.ToString())
                    {
                        cnt++;
                    }
                    else if (cnt == 9)
                    {
                        MessageBox.Show("Game is Over");
                        Close();
                    }
                    else
                    {
                        return;
                    }
                }
            }
            
        }
    }
}
