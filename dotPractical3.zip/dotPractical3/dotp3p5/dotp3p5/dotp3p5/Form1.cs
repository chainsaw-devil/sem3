﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dotp3p5
{
    public partial class Form1 : Form
    {
        int row, col;
        string[,] str;
        int r, c;
        int last_row, last_col, k, l;

        public Form1()
        {
            InitializeComponent();
            r = c = 0;
            k = l = 0;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int i;
            
            while (k <= last_row && l <= last_col)
            {
                for (i = l; i <= last_col; i++)
                {
                    cmatrix.Text = cmatrix.Text + str[k, i] + " ";


                }
                k++;
                for (i = k; i <= last_row; i++)
                {
                    cmatrix.Text = cmatrix.Text + str[i, last_col] + " ";

                }
                last_col--;
                if (k <= last_row)
                {
                    for (i = last_col; i >= l; i--)
                    {
                        cmatrix.Text = cmatrix.Text + str[last_row, i] + " ";

                    }
                    last_row--;
                }
                if (l <= last_col)
                {
                    for (i = last_row; i >= k; i--)
                    {
                        cmatrix.Text = cmatrix.Text + str[i, l] + " ";

                    }
                    l++;
                }
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            matrix.Text = "";
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    matrix.Text = matrix.Text + str[i, j] + " ";
                }
                matrix.Text = matrix.Text + "\n";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                row = Convert.ToInt32(textBox1.Text);
                col = Convert.ToInt32(textBox2.Text);
                str = new string[row, col];
                button1.Enabled = false;
                last_row = row - 1;
                last_col = col - 1;
            }
            catch { MessageBox.Show("Please fill all field"); }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (r == row - 1 && c == col)
            {
                MessageBox.Show("Array is Full");

            }
            else
            {
                if (c == col)
                {
                    c = 0;
                    r++;
                }
                str[r, c] = textBox3.Text;

                c++;

            }

            textBox3.Clear();
        }
    }
}