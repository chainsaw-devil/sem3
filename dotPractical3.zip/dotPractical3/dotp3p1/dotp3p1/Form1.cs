﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace dotp3p1
{
    public partial class Form1 : Form
    {
        string path;
        string oldstr;
        int pasteCheck = 0;
        public Form1()
        {
            InitializeComponent();
            path = "";
            oldstr = "";
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (oldstr == richTextBox1.Text)
            {
                clearAll();
            }
            else
            {
                DialogResult res = MessageBox.Show("Do you want to save", "Confirmation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (res == DialogResult.Yes)
                {
                    saveToolStripMenuItem_Click(sender, e);
                    clearAll();
                }
                else if (res == DialogResult.No)
                {

                    clearAll();
                }
            }

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (path == "")
            {
                oldstr = richTextBox1.Text;
                saveFileDialog1.ShowDialog();
            }
            else
            {
                oldstr = richTextBox1.Text;
                string s = richTextBox1.Text;
                string[] i = s.Split('\n');
                File.WriteAllLines(path, i);
                saveFileDialog1.FileName = "";
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (oldstr == richTextBox1.Text)
            {
                Close();
            }
            else
            {
                DialogResult res = MessageBox.Show("Do you want to save", "Confirmation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (res == DialogResult.Yes)
                {
                    saveToolStripMenuItem_Click(sender, e);
                    Close();
                }
                else if (res == DialogResult.No)
                {
                    Close();
                }
            }

        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            path = saveFileDialog1.FileName;
            string s = richTextBox1.Text;
            string[] i = s.Split('\n');
            File.WriteAllLines(path, i);
            saveFileDialog1.FileName = "";
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            path = openFileDialog1.FileName;
            StreamReader sr = new StreamReader(path);
            richTextBox1.Text = sr.ReadToEnd();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            oldstr = richTextBox1.Text;
            saveFileDialog1.ShowDialog();
        }

        private void open_ok(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }


        private void clearAll()
        {
            richTextBox1.Clear();
            oldstr = "";
            path = "";
        }

        private void fontToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.Font = fontDialog1.Font;
            }
        }
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pasteCheck = 1;
            richTextBox1.Copy();
        }
        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pasteCheck = 1;
            richTextBox1.Cut();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pasteCheck == 1)
            {
                richTextBox1.Paste();
            }
            else
            {
                MessageBox.Show("Copy or Cut something");
            }

        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }
    }
}