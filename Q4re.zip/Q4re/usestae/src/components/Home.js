import React from 'react';

function Home(props) {
  const addtocart = (newitem) => {
    var flag = false;
    var data= props.cartdata.map(item => {
      if (item.id === newitem.id) {
        item.qty += 1;
        flag = true;
      }
      return item;
    });
    if (!flag) {
      newitem.qty = 1;
      props.setData(props.cartdata.concat(newitem))
    }else{
      props.setData(data)
    }
  }

  return (
    <div className='row'>
      {props.data && props.data.map(item => {
        return (
          <div className='col-sm-12 col-md-6 col-lg-3'>
            <div className="card" >
              <img src={item.image} className="card-img-top" style={{ height: "300px", width: "300px;" }} alt={item.title} />
              <div className="card-body">
                <h5 className="card-title">{item.title}</h5>
                <p className="card-text">{item.price}</p>
                <button className="btn btn-primary" onClick={() => addtocart(item)}>Add to Cart</button>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  );
}

export default Home;
