import React from 'react';
import { useSelector, useDispatch } from 'react-redux'
import { incQty, decQty, remove } from '../redux/ShoppingSlice'

function Cart() {
    const data = useSelector(state => state.shopping);
    const dispatch = useDispatch();
    function CalcGrandTotal() {
        let total = 0;
        data.forEach(element => {
            total += element.price * element.qty;
        });
        return total.toFixed(2);
    }
    return (
        <div>
            <h1>Cart</h1>
            <div className="row justify-content-center align-items-center g-2">
                <div className='col-sm-12'>
                    <div className="row">
                        <div className='col-sm-3'>
                            Name
                        </div>
                        <div className='col-sm-2'>
                            Image
                        </div>
                        <div className='col-sm-1'>
                            Price
                        </div>
                        <div className='col-sm-2'>
                            Quantity
                        </div>
                        <div className='col-sm-2'>
                            Subtotal
                        </div>
                        <div className='col-sm-2'>
                            Delete
                        </div>
                    </div>
                </div>
                {
                    data.map(item => {
                        return (
                            <div className='col-sm-12' key={item.name}>
                                <div className="row">
                                    <div className='col-sm-3'>
                                        {item.title}
                                    </div>
                                    <div className='col-sm-2'>
                                        <img src={item.image} className="thumbnail" style={{ height: "100px", width: "100px" }} alt={item.title} />
                                    </div>
                                    <div className='col-sm-1'>
                                        {item.price}
                                    </div>
                                    <div className='col-sm-2'>
                                        <button type="button" className="btn btn-primary" onClick={() => dispatch(decQty(item.id))} >-</button>
                                        <span>
                                            {item.qty}
                                        </span>
                                        <button type="button" className="btn btn-primary" onClick={() => dispatch(incQty(item.id))}>+</button>
                                    </div>
                                    <div className='col-sm-2'>
                                        {item.price * item.qty}
                                    </div>
                                    <div className='col-sm-2'>
                                        <button type="button" className="btn btn-primary" onClick={() => dispatch(remove(item.id))}>Remove</button>
                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
            <h1 className='display-4'>Grand Total : {CalcGrandTotal()}</h1>
        </div>
    );
}

export default Cart;
