import './App.css';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Cart from './components/Cart';
import {Routes,Route} from 'react-router-dom';
import { useEffect, useState } from 'react';

function App() {
  const [Data, setData] = useState([]);

  useEffect(() => {
    async function fetchData() {
    var result = await fetch("products.json");
    var jsondata = await result.json();
    setData(jsondata);
    }
    fetchData();
  }, []);

  return (
    <div >
      <Navbar/>
      <Routes>
        <Route path='/' element={<Home data={Data}/>} />
        <Route path='/Cart' element={<Cart/>} />
      </Routes>
    </div>
  );
}

export default App;
