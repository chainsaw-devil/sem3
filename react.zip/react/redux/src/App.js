import './App.css';
import {useSelector,useDispatch} from 'react-redux'
import {increment,decrement} from './redux/CounterSlice'
function App() {
  const count = useSelector((state)=>state.counter.value);
  const dispatch = useDispatch();
  return (
    <div className="App">
      <input name="" id="" className="btn btn-primary" type="button" value="Increment" onClick={()=>dispatch(increment())}/>
      <span>{count}</span>
      <input name="" id="" className="btn btn-primary" type="button" value="Decrement" onClick={()=>dispatch(decrement())}/>
    </div>
  );
}

export default App;
