import { createSlice } from '@reduxjs/toolkit'

const ivalue = {
    value: 0
}

export const CounterSlice = createSlice({
    name: 'counter',
    initialState:ivalue,
    reducers: {
        increment: (state) => {
            state.value += 1;
        },
        decrement: (state) => {
            if(state.value>0)
            state.value -= 1;
        }
    }
})

console.log(CounterSlice);

export const { increment,decrement } = CounterSlice.actions;

export default CounterSlice.reducer;