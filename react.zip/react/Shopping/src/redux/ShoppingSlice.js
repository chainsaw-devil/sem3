import { createSlice } from '@reduxjs/toolkit'

export const shoppingSlice = createSlice({
    name: "shopping",
    initialState: [
    ],
    reducers: {
        addtocart: (state, action) => {
            var flag = false;
            var newitem = action.payload;
            state.forEach(item => {
                if (item.id === newitem.id) {
                    item.qty += 1;
                    flag = true;
                }
            });
            if (!flag) {
                newitem.qty = 1;
                state.push(newitem);
            }
            return state;
        },
        incQty: (state, action) => {
            state = state.map(item => {
                if (item.id === action.payload)
                    item.qty += 1;
                return item;
            });
        },
        decQty: (state, action) => {
            state = state.map(item => {
                if (item.id === action.payload && item.qty > 1)
                    item.qty -= 1;
                return item;
            });
        },
        remove: (state, action) => {
            return state.filter(item => item.id !== action.payload);
        }
    }
})

export const { addtocart, incQty, decQty, remove } = shoppingSlice.actions;

export default shoppingSlice.reducer;