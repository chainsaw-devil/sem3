import './App.css';
import { useReducer,useState } from 'react'

function App() {
 const [idCounter, setidCounter] = useState(1);

  const reducer = (state, action) => {
    switch (action.type) {
      case "add":
        state = [...state, action.payload];
        break;
      case "delete":
        state = state.filter(item => item.id !== action.payload.id);
        break;
    }

    return state;
  }

  const add = (event) => {
    event.preventDefault();
    dispatch({
      type: "add",
      payload: {
        id: idCounter
        , name: event.target["name"].value
        , phoneno: event.target["phoneno"].value
        , email: event.target["email"].value
      }
    })
    setidCounter(idCounter+1);
    event.target.reset();
  }

  const [studdetails, dispatch] = useReducer(reducer, []);

  return (
    <div className="App container-fluid p-5">
      <form onSubmit={add}>
        <input type='text' name='name' placeholder='name' className='form-control' required /> <br />
        <input type='text' name='phoneno' placeholder='Phone No' className='form-control' required/><br />
        <input type='text' name="email" placeholder='Email' className='form-control' required /><br />
        <input class="btn btn-primary" type="submit" value="Save" />
      </form>
      <div class="table-responsive mt-5">
        <table class="table table-primary">
          <thead>
            <tr>
              <th scope="col">Sr.No</th>
              <th scope="col">Name</th>
              <th scope="col">Mobile No</th>
              <th scope="col">Email</th>
              <th scope="col">action</th>
            </tr>
          </thead>
          <tbody style={{ overflowY: "scroll", maxHeight: "70vh" }}>
            {
              studdetails.map(stud => {
                return (
                  <tr class="">
                    <td>{stud.id}</td>
                    <td>{stud.name}</td>
                    <td>{stud.phoneno}</td>
                    <td>{stud.email}</td>
                    <td><button type="button" className="btn btn-primary" onClick={() => dispatch({ type: "delete", payload: stud })} >Delete</button></td>
                  </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;
