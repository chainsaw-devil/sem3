import './App.css';
import { useState } from 'react';
import Navbar from './components/Navbar'
import Home from './components/Home'
import NewBlog from './components/NewBlog'
import About from './components/About'
import { Routes,Route } from 'react-router-dom'

function App() {
  const [BlogData, setBlogData] = useState([
    {
      id:1,
      title:"ABC",
      desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
      dateCreated:"01-07-2023"
    },
    {
      id:2,
      title:"ABC",
      desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
      dateCreated:"01-07-2023"
    },
    {
      id:3,
      title:"ABC",
      desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
      dateCreated:"01-07-2023"
    },
    {
      id:4,
      title:"ABC",
      desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
      dateCreated:"01-07-2023"
    }
  ]);

  return (
    <>
    <Navbar/>
    <Routes>
      <Route path='/' element={<Home  data={BlogData} />} />
      <Route path='/NewBlog' element={<NewBlog data={BlogData} setData={setBlogData}/>} />
      <Route path='/About' element={<About/>} />
    </Routes>
    </>
  );
}

export default App;
