import React from 'react';

function Home(props) {
  return (
    <div className='container-fluid row'>
      {
        props.data && props.data.map(blog => {
          return (
            <div className='col-sm-12 col-md-6'>
                <div className="card my-5">
                  <h2 className="card-header">
                    {blog.title}
                  </h2>
                  <div className="card-body">
                    <blockquote className="blockquote mb-0">
                      <p>{blog.desc}</p>
                      <footer >Created Date <b title="Source Title">{blog.dateCreated}</b></footer>
                    </blockquote>
                  </div>
                </div>
            </div>)
        })
      }
    </div>
  );
}

export default Home;

