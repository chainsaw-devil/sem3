import React from 'react';

function About() {
  return (
    <div>
      <h1>Made By Dhruv Mistry</h1>
    </div>
  );
}

export default About;
