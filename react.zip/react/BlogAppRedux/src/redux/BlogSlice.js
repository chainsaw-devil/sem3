import { createSlice } from '@reduxjs/toolkit'

export const blogSlice = createSlice({
    name: "blog",
    initialState: [
        {
          id:1,
          title:"ABC",
          desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
          dateCreated:"01-07-2023"
        },
        {
          id:2,
          title:"ABC",
          desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
          dateCreated:"01-07-2023"
        },
        {
          id:3,
          title:"ABC",
          desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
          dateCreated:"01-07-2023"
        },
        {
          id:4,
          title:"ABC",
          desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
          dateCreated:"01-07-2023"
        }
      ],
    reducers: {
        add: (state, action) => {
            return [...state,{
                id: state[state.length-1].id+1,
                title:action.payload.Title,
                desc:action.payload.Desc,
                dateCreated:action.payload.Date
              }]
        }
    }
})

export const { add } = blogSlice.actions;

export default blogSlice.reducer;