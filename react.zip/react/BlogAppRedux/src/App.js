import './App.css';
import Navbar from './components/Navbar'
import Home from './components/Home'
import NewBlog from './components/NewBlog'
import About from './components/About'
import { Routes,Route } from 'react-router-dom'
import { useSelector } from 'react-redux';

function App() {
  const BlogData=useSelector(state=>state.blog);

  return (
    <>
    <Navbar/>
    <Routes>
      <Route path='/' element={<Home data={BlogData} />} />
      <Route path='/NewBlog' element={<NewBlog/>} />
      <Route path='/About' element={<About/>} />
    </Routes>
    </>
  );
}

export default App;
