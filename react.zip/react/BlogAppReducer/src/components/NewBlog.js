import { React, useState } from 'react';

function NewBlog(props) {
  const [Title, setTitle] = useState("");
  const [Desc, setDesc] = useState("");
  const [Date, setDate] = useState("");

  const SubmitHandler = (event) => {
    event.preventDefault();
    props.setData({
      type: "add", payload: {
        id: +props.data[props.data.length - 1].id + 1,
        title: Title,
        desc: Desc,
        dateCreated: Date
      }
    })
    setTitle("");
    setDesc("");
    setDate("");
  }

  return (
    <div>
      <form className='container-fluid' onSubmit={SubmitHandler}>
        <div className="mb-3">
          <label className="form-label">Title</label>
          <input type="text" className="form-control" onChange={event => setTitle(event.target.value)} value={Title} />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">Description</label>
          <textarea class="form-control" name="" rows="3" onChange={event => setDesc(event.target.value)} value={Desc} ></textarea>
        </div>
        <div className="mb-3">
          <label className="form-label">Date</label>
          <input type="date" className="form-control" onChange={event => setDate(event.target.value)} value={Date} />
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
}

export default NewBlog;
