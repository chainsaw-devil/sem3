import './App.css';
import { useReducer } from 'react';
import Navbar from './components/Navbar'
import Home from './components/Home'
import NewBlog from './components/NewBlog'
import About from './components/About'
import { Routes,Route } from 'react-router-dom'

function App() {
  const initialState = [{
    id:1,
    title:"ABC",
    desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
    dateCreated:"01-07-2023"
  },
  {
    id:2,
    title:"ABC",
    desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
    dateCreated:"01-07-2023"
  },
  {
    id:3,
    title:"ABC",
    desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
    dateCreated:"01-07-2023"
  },
  {
    id:4,
    title:"ABC",
    desc:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa dignissimos, quaerat aspernatur adipisci atque harum sapiente non eveniet fuga, voluptatibus soluta, officia impedit esse! Impedit eum in placeat error fugiat!",
    dateCreated:"01-07-2023"
  }]
  
  const reducer = (state,action) =>{
    switch (action.type) {
      case "add":
          return [...state,action.payload]
      default:
        return state;
    }
  }

  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <>
    <Navbar/>
    <Routes>
      <Route path='/' element={<Home  data={state} />} />
      <Route path='/NewBlog' element={<NewBlog data={state} setData={dispatch}/>} />
      <Route path='/About' element={<About/>} />
    </Routes>
    </>
  );
}

export default App;
