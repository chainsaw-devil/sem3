import logo from './logo.svg';
import './App.css';

function App() {


  const submithandler = (e) => {
    e.preventDefault();
    var hobbiesarr = []
    e.target["hobbies"].forEach(item => {
      if (item.checked)
        hobbiesarr.push(item.value)
    });

    alert("Name :" + e.target["name"].value + "\n"
      + "Email :" + e.target["email"].value + "\n"
      + "Password :" + e.target["password"].value + "\n"
      + "DOB :" + e.target["DOB"].value + "\n"
      + "Address :" + e.target["address"].value + "\n"
      + "Gender :" + e.target["gender"].value + "\n"
      + "Course :" + e.target["course"].value + "\n"
      + "Hobbies :" + hobbiesarr.join(",") + "\n")
  }

  return (
    <div className="App">
      <div class="container d-flex justify-content-center align-items-center">
        <form onSubmit={submithandler} className='card p-5 w-50'>
          <div>
            <h1 class="display-3">Registration Form</h1>
          </div>
          <div class="card-body">
            <div class="form-floating mb-3">
              <input
                type="text"
                class="form-control" name="name" />
              <label>Name</label>
            </div>
            <div class="form-floating mb-3">
              <input
                type="email"
                class="form-control" name="email" />
              <label>Email</label>
            </div>
            <div class="form-floating mb-3">
              <input
                type="password"
                class="form-control" name="password" />
              <label>Password</label>
            </div>
            <div class="form-floating mb-3">
              <input
                type="date"
                class="form-control" name="DOB" />
              <label>DOB</label>
            </div>
            <div class="form-floating mb-3">
              <textarea class="form-control" name="address" rows="5"></textarea>
              <label>Address</label>
            </div>
            <div class="form-check-inline d-flex justify-content-evenly mb-3">
              <div><label>Gender</label></div>
              <div>
                <input class="form-check-input" type="radio" name="gender" value="Male" />
                <label class="form-check-label me-3 " for="">
                  Male
                </label>
                <input class="form-check-input" type="radio" name="gender" value="Female" />
                <label class="form-check-label" for="">
                  Female
                </label>
              </div>
            </div>
            <div class="form-floating mb-3">
              <select class="form-select" name="course">
                <option selected>Select one</option>
                <option value="MCA">MCA</option>
                <option value="MBA">MBA</option>
                <option value="M.COM">M.COM</option>
              </select>
              <label for="" class="form-label">Course</label>
            </div>
            <div class="form-check-inline d-flex justify-content-evenly mb-3">
              <div><label>Hobbies</label></div>
              <div>
                <input class="form-check-input" type="checkbox" name="hobbies" id="" value="Reading" />
                <label class="form-check-label me-3 " for="">
                  Reading
                </label>
                <input class="form-check-input" type="checkbox" name="hobbies" id="" value="Swimming" />
                <label class="form-check-label" for="">
                  Swimming
                </label>
                <input class="form-check-input" type="checkbox" name="hobbies" id="" value="Singing" />
                <label class="form-check-label" for="">
                  Singing
                </label>
              </div>
            </div>
            <div class="form-group mb-3">
              <button type="submit" class="btn btn-primary btn-lg">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default App;
