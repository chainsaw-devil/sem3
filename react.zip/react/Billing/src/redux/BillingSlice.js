import { createSlice } from '@reduxjs/toolkit'

export const billingSlice = createSlice({
    name: "billing",
    initialState: [
        {
            name: "Pizza",
            price: 100,
            qty: 1
        },
        {
            name: "Burger",
            price: 200,
            qty: 1
        }
    ],
    reducers: {
        incQty: (state, action) => {
            state= state.map(item => {
                if(item.name === action.payload.name)
                    item.qty +=1;
                return item;
            });
        },
        decQty: (state, action) => {
            state= state.map(item => {
                if(item.name === action.payload.name && item.qty > 1)
                    item.qty -=1;
                return item;
            });
        },
    }
})

export const { incQty, decQty } = billingSlice.actions;

export default billingSlice.reducer;