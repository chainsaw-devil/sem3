import { useReducer } from 'react';
import './App.css';
import Home from './components/Home';

function App() {
  const initialState =[
    {
        name: "Pizza",
        price: 100,
        qty: 1
    },
    {
        name: "Burger",
        price: 200,
        qty: 1
    }
]

const reducer = (state,action)=>{
  switch (action.type) {
    case "inc":
      return state.map(item => {
        if(item.name === action.payload)
            item.qty +=1;
        return item;
    });
      case "dec":
        return state.map(item => {
          if(item.name === action.payload && item.qty > 1)
              item.qty -=1;
          return item;
      });
    default:
      return state;
  }
}

  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <div className="App">
      <Home data={state} dispatch={dispatch} />
    </div>
  );
}

export default App;
