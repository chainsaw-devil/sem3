import { useState } from 'react';
import './App.css';
import Home from './components/Home';

function App() {
  const [Data, setData] = useState([
    {
        name: "Pizza",
        price: 100,
        qty: 1
    },
    {
        name: "Burger",
        price: 200,
        qty: 1
    }
]);

const incQty = (name) => {
  const newdata= Data.map(item => {
      if(item.name === name)
          item.qty +=1;
      return item;
  });
  setData(newdata);
}

const decQty= (name) => {
  const newdata= Data.map(item => {
      if(item.name === name && item.qty > 1)
          item.qty -=1;
      return item;
  });
  setData(newdata);
}

  return (
    <div className="App">
      <Home data={Data} incQty={incQty}  decQty={decQty} />
    </div>
  );
}

export default App;
