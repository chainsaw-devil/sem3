import React from 'react';

function Home(props) {

    function CalcGrandTotal(){
        let total =0;
        props.data.forEach(element => {
            total += element.price * element.qty;
        });
        return total;
    }

    return (
        <div>
            <h1>Billing System</h1>
            <div className="row justify-content-center align-items-center g-2">
                <div className='col-sm-12'>
                    <div className="row">
                        <div className='col-sm-3'>
                            Name
                        </div>
                        <div className='col-sm-3'>
                            Price
                        </div>
                        <div className='col-sm-3'>
                            Quantity
                        </div>
                        <div className='col-sm-3'>
                            Subtotal
                        </div>
                    </div>
                </div>
                {
                    props.data.map(item => {
                        return (
                            <div className='col-sm-12' key={item.name}>
                                <div className="row">
                                    <div className='col-sm-3'>
                                        {item.name}
                                    </div>
                                    <div className='col-sm-3'>
                                        {item.price}
                                    </div>
                                    <div className='col-sm-3'>
                                        <button type="button" className="btn btn-primary" onClick={() => props.decQty(item.name)} >-</button>
                                        <span>
                                            {item.qty}
                                        </span>
                                        <button type="button" className="btn btn-primary" onClick={() => props.incQty(item.name)}>+</button>
                                    </div>
                                    <div className='col-sm-3'>
                                        {item.price * item.qty}
                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
            <h1 className='display-4'>Grand Total : {CalcGrandTotal()}</h1>
        </div>
    );
}

export default Home;
