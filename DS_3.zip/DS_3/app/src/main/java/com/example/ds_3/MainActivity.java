package com.example.ds_3;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    EditText erno,ename,eclass;
    Button btnI,btnU,btnDis;
    ListView l1;
    ArrayAdapter adp;
    ArrayList<String> a=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        erno=findViewById(R.id.editTextTextPersonName);
        ename=findViewById(R.id.editTextTextPersonName2);
        eclass=findViewById(R.id.editTextTextPersonName3);
        btnI=findViewById(R.id.button3);
        btnU=findViewById(R.id.button4);
        btnDis=findViewById(R.id.button6);
        l1=findViewById(R.id.lv1);

        btnI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url="http://192.168.25.154/S/insert.php";
                Response.Listener<String> Listener=new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("response...",""+response);
                        Toast.makeText(MainActivity.this,response, Toast.LENGTH_SHORT).show();
                    }
                };

                Response.ErrorListener errorListener=new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error",""+error.getMessage());
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                };

                StringRequest stringRequest=new StringRequest(Request.Method.POST,url,Listener,errorListener){
                    protected Map<String,String> getParams() throws AuthFailureError{
                        Map<String,String> parameters=new HashMap<>();
                        String roll=erno.getText().toString();
                        String name=ename.getText().toString();
                        String cls=eclass.getText().toString();
                        parameters.put("rollno",roll);
                        parameters.put("name",name);
                        parameters.put("class",cls);
                        return parameters;
                    }
                };

                RequestQueue requestQueue;
                requestQueue= Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            }

        });
    }

    public void btnU(View view) {
        String url="http://192.168.25.154/S/update.php";
        Response.Listener<String> Listener=new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("response...",""+response);
                Toast.makeText(MainActivity.this,response, Toast.LENGTH_SHORT).show();
            }
        };

        Response.ErrorListener errorListener=new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Error",""+error.getMessage());
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };

        StringRequest stringRequest=new StringRequest(Request.Method.POST,url,Listener,errorListener){
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String,String> parameters=new HashMap<>();
                String roll=erno.getText().toString();
                String name=ename.getText().toString();
                String cls=eclass.getText().toString();
                parameters.put("rollno",roll);
                parameters.put("name",name);
                parameters.put("class",cls);
                return parameters;
            }
        };

        RequestQueue requestQueue;
        requestQueue= Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    public void btnD(View view) {
        String url="http://192.168.25.154/S/delete.php";
        Response.Listener<String> Listener=new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("response...",""+response);
                Toast.makeText(MainActivity.this,response, Toast.LENGTH_SHORT).show();
            }
        };

        Response.ErrorListener errorListener=new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Error",""+error.getMessage());
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };

        StringRequest stringRequest=new StringRequest(Request.Method.POST,url,Listener,errorListener){
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String,String> parameters=new HashMap<>();
                String roll=erno.getText().toString();
                parameters.put("rollno",roll);
                return parameters;
            }
        };

        RequestQueue requestQueue;
        requestQueue= Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    public void onV(View view) {
        String url = "http://192.168.25.154/S/display.php";
        Response.Listener<String> Listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("response...", "" + response);
                Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();

                try {
                    JSONArray ja = new JSONArray(response);
                    a.clear();
                    for (int i = 0; i < ja.length(); i++) {
                        JSONObject jo = ja.getJSONObject(i);
                        String reacord = "";
                        reacord += jo.getString("rollno");
                        reacord += "," + jo.getString("name");
                        reacord += "," + jo.getString("class");
                        a.add(reacord);
                    }
                    adp = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, a);
                    l1.setAdapter(adp);

                } catch (JSONException error) {
                    error.printStackTrace();
                    Log.d("Error", "response is not an json array");

                }
            }
        };
        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Error", "" + error.getMessage());
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, Listener, errorListener);
        RequestQueue requestQueue;
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
}