<?php
	if(!empty($_POST['rollno']) && !empty($_POST['name'] && !empty($_POST['class'])))
	{
		$roll=$_POST['rollno'];
		$name=$_POST['name'];
		$class=$_POST['class'];

		$con=mysqli_connect('localhost','root','','s');

		$sql="insert into student values('$roll','$name','$class')";

		if($con)
		{
			if(mysqli_query($con,$sql))
			{
				echo "Data Inserted";
			}
			else
			{
				echo "Insert Failed";
			}
			
		}
		else
		{
			echo "Database not Created";
		}
	}
	else
	{
		echo "Data not Found";
	}
?>