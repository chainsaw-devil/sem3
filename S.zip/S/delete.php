<?php
	if(!empty($_POST['rollno']))
	{
		$roll=$_POST['rollno'];
		

		$con=mysqli_connect('localhost','root','','s');


		if($con)
		{
			$sql = "delete from student where rollno =".$roll;
			if(mysqli_query($con,$sql))
			{
				echo "Data deleted";
			}
			else
			{
				echo "Deletion Failed";
			}
			
		}
		else
		{
			echo "Database not connected";
		}
	}
	
?>