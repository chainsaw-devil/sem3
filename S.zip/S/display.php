<?php
	
	$con=mysqli_connect('localhost','root','','s');

	$sql="select * from student";

	if($con)
	{
		if($row = mysqli_query($con,$sql))
		{
			while($res=mysqli_fetch_array($row))
			{
				$data[]=$res;
			}
			print(json_encode($data));
		}
		else
		{
			echo "Data not found";
		}
			
		}
	else
	{
		echo "Connection Failed...";
	}
	
	
?>