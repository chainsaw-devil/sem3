<?php
	if(!empty($_POST['rollno']) && !empty($_POST['name'] && !empty($_POST['class'])))
	{
		$roll=$_POST['rollno'];
		$name=$_POST['name'];
		$class=$_POST['class'];

		$con=mysqli_connect('localhost','root','','s');

		$sql="update student set name = '$name' , class = '$class' where rollno='$roll' ";

		if($con)
		{
			if(mysqli_query($con,$sql))
			{
				echo "Data Update";
			}
			else
			{
				echo "Updation Failed";
			}
			
		}
		else
		{
			echo "Database not Connected";
		}
	}
	else
	{
		echo "Data not Found";
	}
?>