﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PAS_3
{
    public partial class array_list : Form
    {
        ArrayList n;
        public array_list()
        {
            InitializeComponent();
            n = new ArrayList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int no;
                no = Convert.ToInt32(textBox1.Text.ToString());
                n.Add(no);
                textBox1.Text = "";
                updatelist();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                n.Sort();
                updatelist();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        void updatelist()
        {
            listBox1.Items.Clear();
            foreach(int no in n)
            {
                listBox1.Items.Add(no);
            }
        }
    }
}
