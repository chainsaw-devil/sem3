﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAS_3
{
    public partial class calculatro : Form
    {
        double FirstNumber;
        String Operation;
        double MemoryStore = 0;
        private bool memFlag;

        public calculatro()
        {
            InitializeComponent();

            bmc.Enabled = false;
            bmr.Enabled = false;

        }

        private void btn_click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn == b1)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag==true)
                {
                    textBox1.Text = "1";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "1";
                }              
            }

            if (btn == b2)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag == true)
                {
                    textBox1.Text = "2";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "2";
                }
            }

            if (btn == b3)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag == true)
                {
                    textBox1.Text = "3";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "3";
                }
            }

            if (btn == b4)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag == true)
                {
                    textBox1.Text = "4";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "4";
                }
            }

            if (btn == b5)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag == true)
                {
                    textBox1.Text = "5";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "5";
                }
            }

            if (btn == b6)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag == true)
                {
                    textBox1.Text = "6";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "6";
                }
            }

            if (btn == b7)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag == true)
                {
                    textBox1.Text = "7";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "7";
                }
            }

            if (btn == b8)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag == true)
                {
                    textBox1.Text = "8";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "8";
                }
            }

            if (btn == b9)
            {
                if (textBox1.Text == "0" && textBox1.Text != null || memFlag == true)
                {
                    textBox1.Text = "9";
                    memFlag = false;
                }
                else
                {
                    textBox1.Text += "9";
                }
            }

            if (btn == bdot)
            {
                textBox1.Text += ".";               
            }

            if (btn == b0)
            {
                textBox1.Text += "0";              
            }

            if (btn == Bc)
            {
                textBox1.Text = "0";
            }

            if (btn == bplus)
            {
                FirstNumber = Convert.ToDouble(textBox1.Text);
                textBox1.Text = "0";
                Operation = "+";
            }

            if (btn == bminus)
            {
                FirstNumber = Convert.ToDouble(textBox1.Text);
                textBox1.Text = "0";
                Operation = "-";
            }

            if (btn == bmul)
            {
                FirstNumber = Convert.ToDouble(textBox1.Text);
                textBox1.Text = "0";
                Operation = "*";
            }

            if (btn == bdiv)
            {
                FirstNumber = Convert.ToDouble(textBox1.Text);
                textBox1.Text = "0";
                Operation = "/";
            }
            if (btn == bqual)
            {
                double SecondNumber;
                double Result;

                SecondNumber = Convert.ToDouble(textBox1.Text);
                if (Operation == "+")
                {
                    Result = (FirstNumber + SecondNumber);
                    textBox1.Text = Convert.ToString(Result);
                    FirstNumber = Result;
                }
                if (Operation == "-")
                {
                    Result = (FirstNumber - SecondNumber);
                    textBox1.Text = Convert.ToString(Result);
                    FirstNumber = Result;
                }
                if (Operation == "*")
                {
                    Result = (FirstNumber * SecondNumber);
                    textBox1.Text = Convert.ToString(Result);
                    FirstNumber = Result;
                }
                if (Operation == "/")
                {
                    if (SecondNumber == 0)
                    {
                        textBox1.Text = "Cannot divide by zero";

                    }
                    else
                    {
                        Result = (FirstNumber / SecondNumber);
                        textBox1.Text = Convert.ToString(Result);
                        FirstNumber = Result;
                    }
                }
            }

            //Memory Save
            if (btn == bms)
            {
                MemoryStore = double.Parse(textBox1.Text);
                bmc.Enabled = true;
                bmr.Enabled = true;
                memFlag = true;
            }
            //Memory Read
            if (btn == bmr)
            {
                textBox1.Text = MemoryStore.ToString();
                memFlag = true;
            }

            //Memory Clear
            if (btn == bmc)
            {
                textBox1.Text = "0";
                MemoryStore = 0;
                bmc.Enabled = false;
                bmr.Enabled = false;
            }

            //M+
            if (btn == bmplus)
            {
                MemoryStore += double.Parse(textBox1.Text);
            }

            //M-
            if (btn == bmminus)
            {
                MemoryStore -= double.Parse(textBox1.Text);
            }
        }
    }
}
