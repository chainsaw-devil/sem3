﻿namespace PAS_3
{
    partial class calculatro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.b7 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.Bc = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.bdot = new System.Windows.Forms.Button();
            this.bdiv = new System.Windows.Forms.Button();
            this.bmul = new System.Windows.Forms.Button();
            this.bminus = new System.Windows.Forms.Button();
            this.bplus = new System.Windows.Forms.Button();
            this.bmplus = new System.Windows.Forms.Button();
            this.bms = new System.Windows.Forms.Button();
            this.bmr = new System.Windows.Forms.Button();
            this.bmc = new System.Windows.Forms.Button();
            this.bqual = new System.Windows.Forms.Button();
            this.bmminus = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.bqual);
            this.panel1.Controls.Add(this.bmminus);
            this.panel1.Controls.Add(this.bmplus);
            this.panel1.Controls.Add(this.bms);
            this.panel1.Controls.Add(this.bmr);
            this.panel1.Controls.Add(this.bmc);
            this.panel1.Controls.Add(this.bdiv);
            this.panel1.Controls.Add(this.bmul);
            this.panel1.Controls.Add(this.bminus);
            this.panel1.Controls.Add(this.bplus);
            this.panel1.Controls.Add(this.Bc);
            this.panel1.Controls.Add(this.b0);
            this.panel1.Controls.Add(this.bdot);
            this.panel1.Controls.Add(this.b3);
            this.panel1.Controls.Add(this.b2);
            this.panel1.Controls.Add(this.b1);
            this.panel1.Controls.Add(this.b6);
            this.panel1.Controls.Add(this.b5);
            this.panel1.Controls.Add(this.b4);
            this.panel1.Controls.Add(this.b9);
            this.panel1.Controls.Add(this.b8);
            this.panel1.Controls.Add(this.b7);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(332, 390);
            this.panel1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(326, 52);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // b7
            // 
            this.b7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.Location = new System.Drawing.Point(3, 61);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(60, 60);
            this.b7.TabIndex = 1;
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.btn_click);
            // 
            // b8
            // 
            this.b8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.Location = new System.Drawing.Point(69, 61);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(60, 60);
            this.b8.TabIndex = 2;
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.btn_click);
            // 
            // b9
            // 
            this.b9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.Location = new System.Drawing.Point(135, 61);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(60, 60);
            this.b9.TabIndex = 3;
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.btn_click);
            // 
            // b6
            // 
            this.b6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.Location = new System.Drawing.Point(135, 127);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(60, 60);
            this.b6.TabIndex = 6;
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.btn_click);
            // 
            // b5
            // 
            this.b5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.Location = new System.Drawing.Point(69, 127);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(60, 60);
            this.b5.TabIndex = 5;
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.btn_click);
            // 
            // b4
            // 
            this.b4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.Location = new System.Drawing.Point(3, 127);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(60, 60);
            this.b4.TabIndex = 4;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.btn_click);
            // 
            // b3
            // 
            this.b3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.Location = new System.Drawing.Point(135, 193);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(60, 60);
            this.b3.TabIndex = 3;
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.btn_click);
            // 
            // b2
            // 
            this.b2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.Location = new System.Drawing.Point(69, 193);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(60, 60);
            this.b2.TabIndex = 8;
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.btn_click);
            // 
            // b1
            // 
            this.b1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.Location = new System.Drawing.Point(3, 193);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(60, 60);
            this.b1.TabIndex = 7;
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.btn_click);
            // 
            // Bc
            // 
            this.Bc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bc.Location = new System.Drawing.Point(135, 259);
            this.Bc.Name = "Bc";
            this.Bc.Size = new System.Drawing.Size(60, 60);
            this.Bc.TabIndex = 12;
            this.Bc.Text = "C";
            this.Bc.UseVisualStyleBackColor = true;
            this.Bc.Click += new System.EventHandler(this.btn_click);
            // 
            // b0
            // 
            this.b0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b0.Location = new System.Drawing.Point(69, 259);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(60, 60);
            this.b0.TabIndex = 11;
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = true;
            this.b0.Click += new System.EventHandler(this.btn_click);
            // 
            // bdot
            // 
            this.bdot.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdot.Location = new System.Drawing.Point(3, 259);
            this.bdot.Name = "bdot";
            this.bdot.Size = new System.Drawing.Size(60, 60);
            this.bdot.TabIndex = 10;
            this.bdot.Text = ".";
            this.bdot.UseVisualStyleBackColor = true;
            this.bdot.Click += new System.EventHandler(this.btn_click);
            // 
            // bdiv
            // 
            this.bdiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdiv.Location = new System.Drawing.Point(201, 259);
            this.bdiv.Name = "bdiv";
            this.bdiv.Size = new System.Drawing.Size(60, 60);
            this.bdiv.TabIndex = 16;
            this.bdiv.Text = "/";
            this.bdiv.UseVisualStyleBackColor = true;
            this.bdiv.Click += new System.EventHandler(this.btn_click);
            // 
            // bmul
            // 
            this.bmul.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmul.Location = new System.Drawing.Point(201, 193);
            this.bmul.Name = "bmul";
            this.bmul.Size = new System.Drawing.Size(60, 60);
            this.bmul.TabIndex = 13;
            this.bmul.Text = "*";
            this.bmul.UseVisualStyleBackColor = true;
            this.bmul.Click += new System.EventHandler(this.btn_click);
            // 
            // bminus
            // 
            this.bminus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bminus.Location = new System.Drawing.Point(201, 127);
            this.bminus.Name = "bminus";
            this.bminus.Size = new System.Drawing.Size(60, 60);
            this.bminus.TabIndex = 15;
            this.bminus.Text = "-";
            this.bminus.UseVisualStyleBackColor = true;
            this.bminus.Click += new System.EventHandler(this.btn_click);
            // 
            // bplus
            // 
            this.bplus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bplus.Location = new System.Drawing.Point(201, 61);
            this.bplus.Name = "bplus";
            this.bplus.Size = new System.Drawing.Size(60, 60);
            this.bplus.TabIndex = 14;
            this.bplus.Text = "+";
            this.bplus.UseVisualStyleBackColor = true;
            this.bplus.Click += new System.EventHandler(this.btn_click);
            // 
            // bmplus
            // 
            this.bmplus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmplus.Location = new System.Drawing.Point(267, 193);
            this.bmplus.Name = "bmplus";
            this.bmplus.Size = new System.Drawing.Size(60, 60);
            this.bmplus.TabIndex = 20;
            this.bmplus.Text = "M+";
            this.bmplus.UseVisualStyleBackColor = true;
            this.bmplus.Click += new System.EventHandler(this.btn_click);
            // 
            // bms
            // 
            this.bms.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bms.Location = new System.Drawing.Point(267, 329);
            this.bms.Name = "bms";
            this.bms.Size = new System.Drawing.Size(60, 60);
            this.bms.TabIndex = 17;
            this.bms.Text = "MS";
            this.bms.UseVisualStyleBackColor = true;
            this.bms.Click += new System.EventHandler(this.btn_click);
            // 
            // bmr
            // 
            this.bmr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmr.Location = new System.Drawing.Point(267, 127);
            this.bmr.Name = "bmr";
            this.bmr.Size = new System.Drawing.Size(60, 60);
            this.bmr.TabIndex = 19;
            this.bmr.Text = "MR";
            this.bmr.UseVisualStyleBackColor = true;
            this.bmr.Click += new System.EventHandler(this.btn_click);
            // 
            // bmc
            // 
            this.bmc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmc.Location = new System.Drawing.Point(267, 61);
            this.bmc.Name = "bmc";
            this.bmc.Size = new System.Drawing.Size(60, 60);
            this.bmc.TabIndex = 18;
            this.bmc.Text = "MC";
            this.bmc.UseVisualStyleBackColor = true;
            this.bmc.Click += new System.EventHandler(this.btn_click);
            // 
            // bqual
            // 
            this.bqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bqual.Location = new System.Drawing.Point(3, 325);
            this.bqual.Name = "bqual";
            this.bqual.Size = new System.Drawing.Size(258, 60);
            this.bqual.TabIndex = 21;
            this.bqual.Text = "=";
            this.bqual.UseVisualStyleBackColor = true;
            this.bqual.Click += new System.EventHandler(this.btn_click);
            // 
            // bmminus
            // 
            this.bmminus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmminus.Location = new System.Drawing.Point(267, 259);
            this.bmminus.Name = "bmminus";
            this.bmminus.Size = new System.Drawing.Size(60, 60);
            this.bmminus.TabIndex = 20;
            this.bmminus.Text = "M-";
            this.bmminus.UseVisualStyleBackColor = true;
            this.bmminus.Click += new System.EventHandler(this.btn_click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(354, 416);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Bc;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button bdot;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button bmplus;
        private System.Windows.Forms.Button bms;
        private System.Windows.Forms.Button bmr;
        private System.Windows.Forms.Button bmc;
        private System.Windows.Forms.Button bdiv;
        private System.Windows.Forms.Button bmul;
        private System.Windows.Forms.Button bminus;
        private System.Windows.Forms.Button bplus;
        private System.Windows.Forms.Button bqual;
        private System.Windows.Forms.Button bmminus;
    }
}

