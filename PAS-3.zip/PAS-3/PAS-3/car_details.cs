﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAS_3
{
    public partial class car_details : Form
    {
        private List<car> cars = new List<car>();
        public car_details()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string company = textBox1.Text.ToString();
                string model = textBox2.Text.ToString();
                string color = textBox3.Text.ToString();
                double price = double.Parse(textBox4.Text);

                car c = new car(company, model, color, price);
                cars.Add(c);

                FlowLayoutPanel panel = new FlowLayoutPanel();
                panel.AutoSize = true;
                panel.MaximumSize = new Size(600, 0); // set maximum width and allow any height
                panel.FlowDirection = FlowDirection.TopDown;
                panel.BorderStyle = BorderStyle.FixedSingle;
                panel.Margin = new Padding(5);
                panel.AutoScroll = true;


                Label carLabel = new Label();
                carLabel.Text = "--- Entered Car Details ---";
                carLabel.AutoSize = true;
                carLabel.Font = new Font("Segoe UI", 12, FontStyle.Bold);
                panel.Controls.Add(carLabel);

                Label comapnylabel = new Label();
                comapnylabel.Text = $"Company : {c.company}";
                comapnylabel.AutoSize = true;
                panel.Controls.Add(comapnylabel);

                Label modelLabel = new Label();
                modelLabel.Text = $"Model: {c.model}";
                modelLabel.AutoSize = true;
                panel.Controls.Add(modelLabel);

                Label colorLabel = new Label();
                colorLabel.Text = $"Color: {c.color}";
                colorLabel.AutoSize = true;
                panel.Controls.Add(colorLabel);

                Label priceLabel = new Label();
                priceLabel.Text = $"Price: {c.price}";
                priceLabel.AutoSize = true;
                panel.Controls.Add(priceLabel);

                this.Controls.Add(panel);

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }
    }
}
