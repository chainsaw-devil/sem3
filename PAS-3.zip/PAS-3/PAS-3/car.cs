﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAS_3
{
    class car
    {
        public string company;
        public string model;
        public string color;
        public double price;

        public car(string c,string m,string co,double p)
        {
            company = c;
            model = m;
            color = co;
            price = p;
        }

        public string display()
        {
            return $"{company} {model} {color} {price}";
        }
    }
}
